package com.example.nsbmdays;

import android.os.Bundle;
import android.app.Activity;
import android.app.DownloadManager.Request;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ListView;

public class Selecting extends Activity 
{
	
	//Button Declaration
	Button sEditor;
	Button sViewer;
	Button admin;

	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_selecting);
		
		//Button Define
		sEditor = (Button)findViewById(R.id.btnSEditor);
		sViewer = (Button)findViewById(R.id.btnSViewer);
		admin = (Button)findViewById(R.id.btnAdmin);
		
		//sEditor Button Click
		sEditor.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				startActivity(new Intent(Selecting.this,SheduleEditor.class));
			}
		});
		
		//sViewer Button Click
		sViewer.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startActivity(new Intent(Selecting.this,SheduleViewer.class));
			}
		});
		
		//Administer Button Click
		admin.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				startActivity(new Intent(Selecting.this,AdminMaintain.class));
			}
		});
		
	}
	
	@Override
	public boolean onCreateOptionsMenu(android.view.Menu menu) 
	{
		super .onCreateOptionsMenu(menu);
		MenuInflater blowUp = getMenuInflater();
		blowUp.inflate(R.menu.setting_menu, menu);
		return true;
	}
	
	//Home Button to back page
	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		// TODO Auto-generated method stub
		if(android.R.id.home==item.getItemId())
		{
			finish();
		}
				return super.onOptionsItemSelected(item);
	}
	
	

}
