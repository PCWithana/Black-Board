package com.example.nsbmdays;

import java.security.PublicKey;

import android.media.ExifInterface;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Login extends Activity {

	//Edit Text Fields Declaration
	public EditText uName;
	public EditText pass;
	
	//Button Declaration
	Button signIn;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{	
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		
		//Buttons Define
		signIn =(Button)findViewById(R.id.btnSignIn);
		
		//Edit Text Define
		uName =(EditText)findViewById(R.id.txtUName);
		pass =(EditText)findViewById(R.id.txtPass);
		
		//Sign in button works here
		signIn.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View arg0) 
			{
				Toast.makeText(getBaseContext(),"Succeeded...", Toast.LENGTH_SHORT).show();
				startActivity(new Intent(Login.this,Selecting.class));	
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		// getMenuInflater().inflate(R.menu.login, menu);
		// return true;
		MenuInflater mif = getMenuInflater();
		mif.inflate(R.menu.login_activity_action,menu);
		return super.onCreateOptionsMenu(menu);
	}
	
	//Home Button to quit
			@Override
			public boolean onOptionsItemSelected(MenuItem item)
			{
				// TODO Auto-generated method stub
				if(android.R.id.home==item.getItemId())
				{
					Intent intent = new Intent(Intent.ACTION_MAIN);
					intent.addCategory(Intent.CATEGORY_HOME);
					intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					startActivity(intent);
				}
				
				// Handle presses on the action bar items
			    switch (item.getItemId()) 
			    {
			        case R.id.refresh_icon:
			        	uName.setText("");
			        	pass.setText("");
			            return true;
			    }
	            return super.onOptionsItemSelected(item);
			}

}
