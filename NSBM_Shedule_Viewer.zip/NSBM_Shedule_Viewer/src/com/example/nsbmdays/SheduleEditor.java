package com.example.nsbmdays;

import java.util.Calendar;

import android.os.Bundle;
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

public class SheduleEditor extends Activity 
{
	//Time Picker & Date Dialog Declaration
	static final int stpDialog = 0;
	static final int endDialog = 0;
	static final int datDialog = 1;
	int hour,minute,yr,day,month;
	
	//Labels Declaration
	TextView stText;
	TextView enText;
	TextView daText;
	
	//Button Declaration
	Button stTime;
	Button enTime;
	Button date;
	
	//String Declaration
	String timeOfDay,min;
	
	//Boolean Declaration
	Boolean tZVal;
	
	@SuppressWarnings("deprecation")
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_shedule_editor);
		
		//Labels Define
		stText = (TextView)findViewById(R.id.lblSTime);
		enText = (TextView)findViewById(R.id.lblETime);
		daText = (TextView)findViewById(R.id.lblDate);
		
		//Buttons Define
		stTime =(Button)findViewById(R.id.btnSTime);
		enTime =(Button)findViewById(R.id.btnETime);
		date =(Button)findViewById(R.id.btnDate);
		
		//DatePicker Calendar Declaration and define
		Calendar today = Calendar.getInstance();
		yr = today.get(Calendar.YEAR);
		day = today.get(Calendar.DAY_OF_MONTH);
		month = today.get(Calendar.MONTH);
		
		//Date Time Button
		date.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				showDialog(datDialog);
			}
		});
		
		//Start Time Button
		stTime.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View arg0) 
			{
				tZVal=true;
				showDialog(stpDialog);
			}
		});
		
		//End Time Button
		enTime.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				tZVal=false;
				showDialog(endDialog);
			}
		});
	}
	
	//Dialog Box works
	protected Dialog onCreateDialog(int id) 
	{
		switch (id) 
		{
		case stpDialog:
			return new TimePickerDialog(this, mTimeSetListener, hour, minute, false);
		}

		switch (id) 
		{
		case datDialog:
			return new DatePickerDialog(this, mDateSetListener, yr, month,day);
		}
		return null;
	}
	
	public DatePickerDialog.OnDateSetListener mDateSetListener = 
			new DatePickerDialog.OnDateSetListener() 
	{
		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) 
		{
			// TODO Auto-generated method stub
			yr = year;
			day = dayOfMonth;
			month = monthOfYear;
			Toast.makeText(getBaseContext(), "Date set to " + day + "/" + (month+1) + "/" + yr, Toast.LENGTH_LONG).show();
			daText.setText("\t\t\t"+ day +"/"+ (month+1) +"/"+ yr);
		}
	};
	
	public TimePickerDialog.OnTimeSetListener mTimeSetListener = 
			new TimePickerDialog.OnTimeSetListener() 
	{
				@Override
				public void onTimeSet(TimePicker view, int hourOfDay, int houre_minute) 
				{
					// TODO Auto-generated method stub
					hour = hourOfDay;
					minute = houre_minute;
					
					if(12<hour)
					{
						hour=hour-12;
						timeOfDay="PM";
					}
					else
					{
						timeOfDay="AM";
					}
					if(minute<10)
					{
						min="0"+minute;
					}
					else
					{
						min=minute+"";
					}
					
					Toast.makeText(getBaseContext(), "Time set to "+ hour + ":" + min +":"+ timeOfDay, Toast.LENGTH_LONG).show();
					
					if(tZVal==true)
					{
					stText.setText("\t\t\t"+ hour +":"+ min +":"+ timeOfDay);
					}
					else
					{
					enText.setText("\t\t\t"+ hour +":"+ min +":"+ timeOfDay);
					}
				}
	};
		
	@Override
	public boolean onCreateOptionsMenu(android.view.Menu menu) 
	{	//menu buttons
		super .onCreateOptionsMenu(menu);
		MenuInflater blowUp = getMenuInflater();
		blowUp.inflate(R.menu.setting_menu, menu);
		
		//action bar buttons
		MenuInflater mif = getMenuInflater();
		mif.inflate(R.menu.action_bar_actions,menu);
		return super.onCreateOptionsMenu(menu);
	}
	
	//Home Button to back page
	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		// TODO Auto-generated method stub
		if(android.R.id.home==item.getItemId())
		{
			finish();
		}
		
		// Handle presses on the action bar items
	    switch (item.getItemId()) 
	    {
	        case R.id.search_icon:
	        	//search icon work here
	            return true;
	        case R.id.save_icon:
	        	//save icon work here
	        	return true;
	        case R.id.edit_icon:
	        	//edit icon work here
	        	return true;
	        case R.id.delete_icon:
	        	//delete icon work here
	        	return true;
	        case R.id.settAboutUs:
	        	startActivity(new Intent(SheduleEditor.this,About.class));
	        	//Activity Transition works here
				overridePendingTransition(R.animator.animation1,R.animator.animation2);
	            return true;
	        case R.id.settSignOut:
	        	//sign out text works here
	        	return true;
	    }
        return super.onOptionsItemSelected(item);
	}
			
}
