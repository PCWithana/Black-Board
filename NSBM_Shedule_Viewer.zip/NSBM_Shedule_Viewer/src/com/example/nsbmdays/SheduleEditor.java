package com.example.nsbmdays;

import java.security.spec.EllipticCurve;
import java.util.Calendar;

import android.R.string;
import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

public class SheduleEditor extends Activity {

	//Time Picker & Date Dialog Declaration
	static final int stpDialog = 0;
	static final int endDialog = 0;
	static final int datDialog = 0;
	int hour,minute,yr,day,month;
	String duration;
	
	
	@SuppressWarnings("deprecation")
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_sheduleeditor);
		
		//Labels
		TextView stText = (TextView)findViewById(R.id.lblSTime);
		TextView enText = (TextView)findViewById(R.id.lblETime);
		TextView daText = (TextView)findViewById(R.id.lblDate);
		
		//Buttons
		Button stTime =(Button)findViewById(R.id.btnSTime);
		Button enTime =(Button)findViewById(R.id.btnETime);
		Button date =(Button)findViewById(R.id.btnDate);
		
		//DatePicker Calendar Declaration and define
		Calendar today = Calendar.getInstance();
		yr = today.get(Calendar.YEAR);
		day = today.get(Calendar.DAY_OF_MONTH);
		month = today.get(Calendar.MONTH);
		
		//Date Time Button
		date.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				showDialog(datDialog);
			}
		});
		
		//Start Time Button
		stTime.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View arg0) 
			{
				showDialog(stpDialog);
			}
		});
		
		//End Time Button
		enTime.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				showDialog(endDialog);
			}
		});
	}
	
	//Dialog Box works
	protected Dialog onCreateDialog(int id) 
	{
		switch (id) 
		{
		case stpDialog:
			return new TimePickerDialog(this, mTimeSetListener, hour, minute, false);
		}
		
		switch (id) 
		{
		case endDialog:
			return new TimePickerDialog(this, mTimeSetListener, hour, minute, false);
		}

		switch (id) 
		{
		case datDialog:
			return new DatePickerDialog(this, mDateSetListener, yr, month,day);
		}
		return null;
	}
	
	private DatePickerDialog.OnDateSetListener mDateSetListener = 
			new DatePickerDialog.OnDateSetListener() 
	{
		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) 
		{
			// TODO Auto-generated method stub
			yr = year;
			day = dayOfMonth;
			month = monthOfYear;
			Toast.makeText(getBaseContext(), "Date is " + day + "/" + (month+1) + "/" + year, Toast.LENGTH_LONG).show();
		}
	};
	
	private TimePickerDialog.OnTimeSetListener mTimeSetListener = 
			new TimePickerDialog.OnTimeSetListener() 
	{
				@Override
				public void onTimeSet(TimePicker view, int hourOfDay, int houre_minute) 
				{
					// TODO Auto-generated method stub
					hour = hourOfDay;
					minute = houre_minute;
					if(hour>12)
					{
						hour=hour-12;
						duration="PM";
					}
					else 
					{
						duration="AM";
					}
					Toast.makeText(getBaseContext(), "Time :"+ hour + ":" + minute + ":" + duration, Toast.LENGTH_LONG).show();
				}
	};
		
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.exams, menu);
		return true;
	}
	
	//Home Button to back page
			@Override
			public boolean onOptionsItemSelected(MenuItem item)
			{
				// TODO Auto-generated method stub
				if(android.R.id.home==item.getItemId())
				{
					finish();
				}
				return super.onOptionsItemSelected(item);
			}
			
}
