package com.example.nsbmdays;

import android.os.Bundle;
import android.app.ActionBar;
import android.app.Activity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;

public class About extends Activity {

	//Tab Variable Declaration
	TabHost th;
	TabSpec specs;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_about);
		
		//Tabs On Create
		th =(TabHost)findViewById(R.id.tabh);
		th.setup();
		//Tab 1
		specs = th.newTabSpec("tag1");
		specs.setContent(R.id.tab1);
		specs.setIndicator("About App");
		th.addTab(specs);
		//Tab 2
		specs = th.newTabSpec("tag2");
		specs.setContent(R.id.tab2);
		specs.setIndicator("About Us");
		th.addTab(specs);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		//Action bar home button
		ActionBar aBar = getActionBar();
		aBar.setHomeButtonEnabled(true);
		
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.about, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		if(android.R.id.home==item.getItemId())
		{
			finish();
		}
		return super.onOptionsItemSelected(item);
	}

	
}
