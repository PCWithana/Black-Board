package com.example.nsbmdays;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.AsyncTask;
import android.os.Bundle;
import android.app.ActionBar;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;

public class OneByOne extends Activity {
	
	TextView  StartTime;
	TextView  EndTime;
	TextView DateHeld;
	TextView Building;
	TextView HallN;
	TextView Note;
	TextView event;
	String sid;

	private ProgressDialog pDialog;

	// JSON parser class
	JSONParser jsonParser = new JSONParser();

	// single product url
	private static final String url_shedule_detials = "http://shedulens.esy.es/get_product_details.php";
	
	private static final String TAG_SUCCESS = "success";
	private static final String TAG_PRODUCT = "products";
	private static final String TAG_SID = "sid";
	private static final String TAG_DATE = "date";
	private static final String TAG_STIME = "stime";
	private static final String TAG_ETIME = "etime";
	private static final String TAG_BUILDING = "buildingname";
	private static final String TAG_HALL = "hall";
	private static final String TAG_NOTE = "note";
	private static final String TAG_SNAME = "shedulename";
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_one_by_one);
		
		
       // Intent i = getIntent();
		
		// getting product id (pid) from intent
		//sid = i.getStringExtra(TAG_SID);
		
		new GetProductDetails().execute();

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) 
	{
		//Action bar home button
		ActionBar actionBar = getActionBar();
		actionBar.setHomeButtonEnabled(true);
		
		super .onCreateOptionsMenu(menu);
		MenuInflater blowUp = getMenuInflater();
		blowUp.inflate(R.menu.setting_menu, menu);
		
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.login_activity_action, menu);
		return true;
	}
	
	
	//Home Button to back page
		@Override
		public boolean onOptionsItemSelected(MenuItem item)
		{
			// TODO Auto-generated method stub
			if(android.R.id.home==item.getItemId())
			{
				finish();
			}
			// Handle presses on the action bar items
		    switch (item.getItemId()) 
		    {
		        case R.id.settAboutUs:
		        	startActivity(new Intent(OneByOne.this,About.class));
		        	//Activity Transition works here
					overridePendingTransition(R.animator.animation1,R.animator.animation2);
		            return true;
		        case R.id.settSignOut:
		        	//sign out text works here
		        	return true;
		    }
	        return super.onOptionsItemSelected(item);
		}


	
	class GetProductDetails extends AsyncTask<String, String, String> {

		/**
		 * Before starting background thread Show Progress Dialog
		 * */
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			pDialog = new ProgressDialog(OneByOne.this);
			pDialog.setMessage("Loading shedule details. Please wait...");
			pDialog.setIndeterminate(false);
			pDialog.setCancelable(true);
			pDialog.show();
		}

		/**
		 * Getting product details in background thread
		 * */
		protected String doInBackground(String... params) {

			// updating UI from Background Thread
			runOnUiThread(new Runnable() {
				public void run() {
					// Check for success tag
					int success;
					Bundle extras = getIntent().getExtras();
					String sid = extras.getString("ssid");
					try {
						// Building Parameters
						List<NameValuePair> params = new ArrayList<NameValuePair>();
						params.add(new BasicNameValuePair("sid",sid));

						// getting product details by making HTTP request
						// Note that product details url will use GET request
						JSONObject json = jsonParser.makeHttpRequest(
								url_shedule_detials, "GET", params);

						// check your log for json response
						Log.d("Single Product Details", json.toString());
						
						// json success tag
						success = json.getInt(TAG_SUCCESS);
						if (success == 1) {
							// successfully received product details
							JSONArray productObj = json
									.getJSONArray(TAG_PRODUCT); // JSON Array
							
							// get first product object from JSON Array
							JSONObject product = productObj.getJSONObject(0);

							// product with this pid found
							// Edit Text
							StartTime = (TextView)findViewById(R.id.viewStartTime);
							EndTime = (TextView) findViewById(R.id.viewEndTime);
							Building = (TextView) findViewById(R.id.viewBuilding);
							HallN = (TextView) findViewById(R.id.viewHallN);
							Note = (TextView) findViewById(R.id.viewNote);
							DateHeld = (TextView) findViewById(R.id.viewDateHeld);
							event = (TextView) findViewById(R.id.viewModOEvn);

							// display product data in EditText
							StartTime.setText(product.getString(TAG_STIME));
							EndTime.setText(product.getString(TAG_ETIME));
							Building.setText(product.getString(TAG_BUILDING));
							HallN.setText(product.getString(TAG_HALL));
							Note.setText(product.getString(TAG_NOTE));
							DateHeld.setText(product.getString(TAG_DATE));
							event.setText(product.getString(TAG_SNAME));
							
						}
						else {
							// product with pid not found
						}
					} catch (JSONException e) {
						e.printStackTrace();
					}
				}
			});

			return null;
		}


		/**
		 * After completing background task Dismiss the progress dialog
		 * **/
		protected void onPostExecute(String file_url) {
			// dismiss the dialog once got all details
			pDialog.dismiss();
		}
	}	
}
