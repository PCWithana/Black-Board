package com.example.nsbmdays;

import android.os.Bundle;
import android.app.Activity;
import android.app.DownloadManager.Request;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;

public class Selecting extends Activity 
{

	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_selecting);
		
		//Button Declaration
		Button exam=(Button)findViewById(R.id.btnExam);
		Button lect=(Button)findViewById(R.id.btnLect);
		
		//Exam Button Click
		exam.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				startActivity(new Intent(Selecting.this,Exams.class));
			}
		});
		
		//Lecture Button Click
		lect.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				startActivity(new Intent(Selecting.this,Lectures.class));
			}
		});
		
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) 
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.selecting, menu);
		return true;
	}
	
	//Home Button to back page
			@Override
			public boolean onOptionsItemSelected(MenuItem item)
			{
				// TODO Auto-generated method stub
				if(android.R.id.home==item.getItemId())
				{
					finish();
				}
				return super.onOptionsItemSelected(item);
			}

}
