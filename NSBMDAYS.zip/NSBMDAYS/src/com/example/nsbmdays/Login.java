package com.example.nsbmdays;

import android.media.ExifInterface;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Login extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{	
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		
		//Buttons
		Button signIn=(Button)findViewById(R.id.btnSignIn);
		
		//Edit Text Fields
		final EditText uName =(EditText)findViewById(R.id.txtUName);
		final EditText pass =(EditText)findViewById(R.id.txtPass);
		
		signIn.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View arg0) 
			{
				startActivity(new Intent(Login.this,Selecting.class));	
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.login, menu);
		return true;

	}
	
	//Home Button to quit
			@Override
			public boolean onOptionsItemSelected(MenuItem item)
			{
				// TODO Auto-generated method stub
				if(android.R.id.home==item.getItemId())
				{
					Intent intent = new Intent(Intent.ACTION_MAIN);
					intent.addCategory(Intent.CATEGORY_HOME);
					intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					startActivity(intent);
				}
				return super.onOptionsItemSelected(item);
			}

}
