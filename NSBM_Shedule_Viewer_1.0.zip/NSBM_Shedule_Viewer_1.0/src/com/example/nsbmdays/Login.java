package com.example.nsbmdays;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.app.ActionBar;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;



public class Login extends Activity {

	
	// Progress Dialog
    private ProgressDialog pDialog;
 
    // Creating JSON Parser object
    JSONParser jsonParser = new JSONParser();
    EditText uid;
    EditText pas;
    Button signIn;
 
    // url to get all products list
    private static String url_all_products = "http://shedulens.esy.es/logincheck.php";
 
    // JSON Node names
    private static final String TAG_SUCCESS = "success";
    private static final String TAG_MESSAGE = "message";
    private static final String TAG_STATUS = "status";
    JSONArray user = null;
    
    public boolean isNetworkOnline() {
        boolean status=false;
        try{
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo netInfo = cm.getNetworkInfo(0);
            if (netInfo != null && netInfo.getState()==NetworkInfo.State.CONNECTED) {
                status= true;
            }else {
                netInfo = cm.getNetworkInfo(1);
                if(netInfo!=null && netInfo.getState()==NetworkInfo.State.CONNECTED)
                    status= true;
            }
        }catch(Exception e){
            e.printStackTrace();  
            return false;
        }
        return status;

        }
	//Edit Text Fields Declaration
	
	//Button Declaration
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) 
	{	
		
		super.onCreate(savedInstanceState);
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		StrictMode.setThreadPolicy(policy);
		
		setContentView(R.layout.activity_login);
		
		//Buttons Define
		signIn =(Button)findViewById(R.id.btnSignIn);
		
		//Edit Text Define
		uid =(EditText)findViewById(R.id.txtPass);
		pas =(EditText)findViewById(R.id.txtUName);
		
		//Sign in button works here
		signIn.setOnClickListener(new View.OnClickListener() 
		{
			@Override
			public void onClick(View view) 
			{
				
				if(isNetworkOnline())
				{
						new CreateNewProduct().execute();
					}
					else
					{
						Toast.makeText(getBaseContext(),"No Internet Connection", Toast.LENGTH_LONG).show();
					}
				
				
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		//Action bar home button
		ActionBar aBar = getActionBar();
		aBar.setHomeButtonEnabled(true);
		
		// Inflate the menu; this adds items to the action bar if it is present.
		MenuInflater mif = getMenuInflater();
		mif.inflate(R.menu.login_activity_action,menu);
		return super.onCreateOptionsMenu(menu);
	}
	
			
			class CreateNewProduct extends AsyncTask<String, String, String> {

				/**
				 * Before starting background thread Show Progress Dialog
				 * */
				@Override
				protected void onPreExecute() {
					super.onPreExecute();
					pDialog = new ProgressDialog(Login.this);
					pDialog.setMessage("Validating...");
					pDialog.setIndeterminate(false);
					pDialog.setCancelable(true);
					pDialog.show();
				}

				/**
				 * Creating product
				 * */
				protected String doInBackground(String... args) {
					String msg = null;
					String userid = uid.getText().toString();
					String pass = pas.getText().toString();
		            
					// Building Parameters
					List<NameValuePair> params = new ArrayList<NameValuePair>();
					params.add(new BasicNameValuePair("userid", userid));
					params.add(new BasicNameValuePair("pass", pass));

					// getting JSON Object
					// Note that create product url accepts POST method
					JSONObject json = jsonParser.makeHttpRequest(url_all_products,
							"GET", params);
					
					// check log cat fro response
					Log.d("Create Response", json.toString());

					// check for success tag
					try {
						int success = json.getInt(TAG_SUCCESS);
		                 msg=json.getString(TAG_MESSAGE);
						
		                 
						if (success == 1){
							
							int status = json.getInt(TAG_STATUS);
							
							if(status==0){
							Intent a = new Intent(getApplicationContext(),Selecting.class);
		                    // Closing all previous activities
		                    startActivity(a);
		    				//Activity Transition works here
		    				overridePendingTransition(R.animator.animation1,R.animator.animation2);
							}
							else{
		    				
		    				Intent i = new Intent(getApplicationContext(),StudentsShedules.class);
		                    // Closing all previous activities
		                    i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		                    String bid=Integer.toString(status);
		                    i.putExtra("batchid",bid);
		                    startActivity(i);
		    				//Activity Transition works here
		    				overridePendingTransition(R.animator.animation1,R.animator.animation2);
							}
		                }
						else {
		        
							
		                }
					} catch (JSONException e) {
						e.printStackTrace();
					}

					return msg;
				}

				/**
				 * After completing background task Dismiss the progress dialog
				 * **/
				protected void onPostExecute(String msg) {
					// dismiss the dialog once done
					pDialog.dismiss();
					Toast.makeText(getBaseContext(),msg, Toast.LENGTH_LONG).show();
					
			}
			}
			
			@Override
			public boolean onOptionsItemSelected(MenuItem item)
			{
				// TODO Auto-generated method stub
				if(android.R.id.home==item.getItemId())
				{
					Intent intent = new Intent(Intent.ACTION_MAIN);
					intent.addCategory(Intent.CATEGORY_HOME);
					intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					startActivity(intent);
				}
				
				// Handle presses on the action bar items
			    switch (item.getItemId()) 
			    {
			    case R.id.refresh_icon:
			        	clearText();
			            return true;
			    }
	            return super.onOptionsItemSelected(item);
			}
			
			// Function For Refresh action
			public void clearText() 
			{
	        	uid.setText("");
	        	pas.setText("");
			}
}
