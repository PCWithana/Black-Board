package com.example.nsbmdays;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.apache.http.NameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.ActionBar;
import android.app.ListActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import org.apache.http.message.BasicNameValuePair;


public class StudentsShedules extends ListActivity {
	
	private ProgressDialog pDialog;

	// Creating JSON Parser object
	JSONParser jParser = new JSONParser();

	ArrayList<HashMap<String, String>> sheduleList;

	// url to get all products list
	private static String url_all_sehdules = "http://shedulens.esy.es/get_all_products.php";

	// JSON Node names
	private static final String TAG_SUCCESS = "success";
	private static final String TAG_SHEDULES = "products";
	private static final String TAG_SID = "sheduleid";
	private static final String TAG_DATE = "date";

	// products JSONArray
	JSONArray shedules = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_students_shedules);
		
		sheduleList = new ArrayList<HashMap<String, String>>();

		// Loading products in Background Thread
		new LoadAllProducts().execute();

		// Get listview
		ListView lv = getListView();
	
		lv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				// getting values from selected ListItem
				String sid = ((TextView) view.findViewById(R.id.sid)).getText().toString();

				// Starting new intent
				Intent in = new Intent(getApplicationContext(),OneByOne.class);
				// sending pid to next activity
				in.putExtra("ssid", sid);
				// starting new activity and expecting some response back
				startActivity(in);
				//Activity Transition works here
				overridePendingTransition(R.animator.animation1,R.animator.animation2);
			}
		});

		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		//Action bar home button
		ActionBar aBar = getActionBar();
		aBar.setHomeButtonEnabled(true);
		
		//menu buttons
		super .onCreateOptionsMenu(menu);
		MenuInflater blowUp = getMenuInflater();
		blowUp.inflate(R.menu.setting_menu, menu);
		return super.onCreateOptionsMenu(menu);
	}
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		// TODO Auto-generated method stub
		if(android.R.id.home==item.getItemId())
		{
			finish();
		}
		// Handle presses on the action bar items
	    switch (item.getItemId()) 
	    {
	        case R.id.settAboutUs:
	        	startActivity(new Intent(StudentsShedules.this,About.class));
	        	//Activity Transition works here
				overridePendingTransition(R.animator.animation1,R.animator.animation2);
	            return true;
	        case R.id.settSignOut:
	        	//sign out text works here
	        	return true;
	    }
        return super.onOptionsItemSelected(item);
	}
	
	class LoadAllProducts extends AsyncTask<String, String, String> {

		/**
		 * Before starting background thread Show Progress Dialog
		 * */
		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			pDialog = new ProgressDialog(StudentsShedules.this);
			pDialog.setMessage("Loading shedules. Please wait...");
			pDialog.setIndeterminate(false);
			pDialog.setCancelable(false);
			pDialog.show();
		}

		/**
		 * getting All products from url
		 * */
		protected String doInBackground(String... args) {
			// Building Parameters
			Bundle extras = getIntent().getExtras();
			String batchid = extras.getString("batchid");
			
			
			List<NameValuePair> params = new ArrayList<NameValuePair>();
			
			
			params.add(new BasicNameValuePair("batchid", batchid));
			// getting JSON string from URL
			JSONObject json = jParser.makeHttpRequest(url_all_sehdules, "GET", params);
			
			// Check your log cat for JSON reponse
			Log.d("All shedules: ", json.toString());

			try {
				// Checking for SUCCESS TAG
				int success = json.getInt(TAG_SUCCESS);

				if (success == 1) {
					// products found
					// Getting Array of Products
					shedules = json.getJSONArray(TAG_SHEDULES);

					// looping through All Products
					for (int i = 0; i < shedules.length(); i++) {
						JSONObject c = shedules.getJSONObject(i);

						// Storing each json item in variable
						String sid = c.getString(TAG_SID);
						String date = c.getString(TAG_DATE);

						// creating new HashMap
						HashMap<String, String> map = new HashMap<String, String>();

						// adding each child node to HashMap key => value
						map.put(TAG_SID, sid);
						map.put(TAG_DATE, date);

						// adding HashList to ArrayList
						sheduleList.add(map);
					}
				} else {
					// no products found
					// Launch Add New product Activity
					Intent i = new Intent(getApplicationContext(),Login.class);
					// Closing all previous activities
					i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(i);
					//Activity Transition works here
					overridePendingTransition(R.animator.animation1,R.animator.animation2);
				}
			} catch (JSONException e) {
				e.printStackTrace();
			}

			return null;
		}

		/**
		 * After completing background task Dismiss the progress dialog
		 * **/
		protected void onPostExecute(String file_url) {
			// dismiss the dialog after getting all products
			pDialog.dismiss();
			// updating UI from Background Thread
			runOnUiThread(new Runnable() {
				public void run() {
					/**
					 * Updating parsed JSON data into ListView
					 * */
					ListAdapter adapter = new SimpleAdapter(
							StudentsShedules.this, sheduleList,
							R.layout.list_item, new String[] { TAG_SID,
									TAG_DATE},
							new int[] { R.id.sid, R.id.date });
					// updating listview
					setListAdapter(adapter);
				}
			});

		}

	}

}
