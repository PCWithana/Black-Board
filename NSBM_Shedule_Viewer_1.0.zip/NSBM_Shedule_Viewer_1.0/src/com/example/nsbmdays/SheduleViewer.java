package com.example.nsbmdays;

import android.os.Bundle;
import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

public class SheduleViewer extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_shedule_viewer);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		//Action bar home button
		ActionBar aBar = getActionBar();
		aBar.setHomeButtonEnabled(true);
		
		//menu buttons
		super .onCreateOptionsMenu(menu);
		MenuInflater blowUp = getMenuInflater();
		blowUp.inflate(R.menu.setting_menu, menu);
		return super.onCreateOptionsMenu(menu);
	}
	
	//Home Button to back page
		@Override
		public boolean onOptionsItemSelected(MenuItem item)
		{
			// TODO Auto-generated method stub
			if(android.R.id.home==item.getItemId())
			{
				finish();
			}
			// Handle presses on the action bar items
		    switch (item.getItemId()) 
		    {
		        case R.id.settAboutUs:
		        	startActivity(new Intent(SheduleViewer.this,About.class));
		        	//Activity Transition works here
					overridePendingTransition(R.animator.animation1,R.animator.animation2);
		            return true;
		        case R.id.settSignOut:
		        	//sign out text works here
		        	return true;
		    }
	        return super.onOptionsItemSelected(item);
		}

}
